//��{1,2,3,4}��ȫ����
#include<stdio.h>
void process(int a[],int k)//�������
{
    int i;
    for(i = 1;i <= k;i++)
    printf("%d ",a[i]);
    puts(" ");
}
int construct(int a[],int k,int n,int c[])
{
    int i;
    int pre[100];
    for(i = 1;i < 100;i++)
    pre[i] = 0;
    for(i = 1;i < k;i++)
    pre[a[i]] = 1;
    int n2 = 0;
    for(i = 1;i <= n;i++)
    if(!pre[i])
    c[n2++] = i;
    return n2;
}
void backtrack(int a[],int k,int n)
{
    int c[100],n2,i;
    if(k == n)
    process(a,k);
    else
    {
        k = k+1;
        n2 = construct(a,k,n,c);
        for(i = 0;i < n2;i++)
        {
            a[k] = c[i];
            backtrack(a,k,n);
        }


    }

}

int main()
{
    int a[100],n;
printf("����n������");
    while(scanf("%d",&n)&&n)
    {
        backtrack(a,0,n);
    }
    return 0;
}